import React, { Component } from "react";

class Seller extends Component {
  render() {
    return (
      <div>


      Hello this is the SELLER's page


      
      </div>
  )
  }
  }

  export default Seller;