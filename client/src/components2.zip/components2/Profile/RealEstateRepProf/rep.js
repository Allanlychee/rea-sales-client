import React, { Component } from "react";

class Representative extends Component {
  render() {
    return (
      <div>


      Hello this is the REPRESENTATIVE's page


      
      </div>
  )
  }
  }

  export default Representative;