export { default } from "./Register";
